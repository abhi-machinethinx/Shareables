from imutils.video import VideoStream
from imutils.video import FPS
import face_recognition
import argparse
import imutils
import pickle
import time
import cv2
import json
import numpy as np
from time import perf_counter

CASCADER = "/data/haarcascades/haarcascade_frontalface_default.xml"
NAMES_FILE = "known_faces.json"
ENCODING_DIR = "Encodings"
KNOWN_ENCODINGS = []
KNOWN_FACES = []
ATTENDANCE = {}


def startWebcam():
    global ATTENDANCE, KNOWN_FACES, KNOWN_ENCODINGS, CASCADER

    detector = cv2.CascadeClassifier("/home/nuc/Documents/Python_Scripts/DLIB/data/haarcascades/haarcascade_frontalface.xml")

    vs = VideoStream(src=0).start()
    time.sleep(2.0)
    fps = FPS().start()

    while True:
        frame = vs.read()
        frame = imutils.resize(frame, width=500)

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)

        # detect faces in the grayscale frame
        rects = detector.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))

        boxes = [(y, x + w, y + h, x) for (x, y, w, h) in rects]

        # compute the facial embeddings for each face bounding box
        encodings = face_recognition.face_encodings(rgb, boxes)

        locations = []
        names = []

        # loop over the facial embeddings
        for eI, encoding in enumerate(encodings):
            maxCount = 0
            fI = -1

            for i, known_encodings in enumerate(KNOWN_ENCODINGS):
                matches = face_recognition.compare_faces(known_encodings,
                                                         encoding, tolerance= 0.5)
                count = 0
                for m in matches:
                    if m:
                        count += 1

                if count > maxCount:
                    maxCount = count
                    fI = i

            if maxCount > 0:
                # update the list of names
                names.append(KNOWN_FACES[fI].get("name"))
                locations.append(boxes[eI])

        # loop over the recognized faces
        for ((top, right, bottom, left), name) in zip(locations, names):
            # draw the predicted face name on the image
            cv2.rectangle(frame, (left, top), (right, bottom),
                          (0, 255, 0), 2)
            y = top - 15 if top - 15 > 15 else top + 15
            cv2.putText(frame, name, (left, y), cv2.FONT_HERSHEY_SIMPLEX,
                        0.75, (0, 255, 0), 2)

        # display the image to our screen
        cv2.imshow("Frame", frame)
        key = cv2.waitKey(1) & 0xFF

        # if the `q` key was pressed, break from the loop
        if key == ord("q"):
            break

        # update the FPS counter
        fps.update()
        # stop the timer and display FPS information
        fps.stop()

        print("[INFO] elasped time: {:.2f}".format(fps.elapsed()))
        print("[INFO] approx. FPS: {:.2f}".format(fps.fps()))

    # do a bit of cleanup
    cv2.destroyAllWindows()
    vs.stop()


def main():
    global NAMES_FILE, KNOWN_ENCODINGS, KNOWN_FACES

    with open(NAMES_FILE) as input:
        KNOWN_FACES = json.load(input)

    for data in KNOWN_FACES:
        faceId = data.get("id")
        ATTENDANCE[data.get("name")] = 0
        embeds = np.load(ENCODING_DIR+"/"+faceId+".npz")
        KNOWN_ENCODINGS.append(embeds['arr_0'])

    startWebcam()


main()

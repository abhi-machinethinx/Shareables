from imutils import paths
import face_recognition
import argparse
import pickle
import cv2
import os
import json
from time import perf_counter
import shutil
import uuid
import numpy as np

FACES_DIR = "Faces"
ENCODING_DIR = "Encodings"
NAMES_FILE = "known_faces.json"

def calc_save_known_face_embeddings():
    global FACES_DIR, ENCODING_DIR, NAMES_FILE
    timeS = perf_counter()

    if os.path.exists(ENCODING_DIR):
        shutil.rmtree(ENCODING_DIR)

    os.makedirs(name=ENCODING_DIR, exist_ok=True)

    faces = []
    encodings = []

    for names_dir in os.listdir(FACES_DIR):
        faceId = str(uuid.uuid4())

        i = 0
        for img in os.listdir(FACES_DIR+"/"+names_dir):
            i += 1
            if i == 1:
                faces.append({"id": faceId, "name": names_dir})

            if img.endswith(".jpg") or img.endswith(".jpeg") or img.endswith(".png") or img.endswith(".JPG") or img.endswith(".JPEG") or img.endswith(".PNG"):
                image = cv2.imread(FACES_DIR+"/"+names_dir+"/"+img)
                rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
                boxes = face_recognition.face_locations(rgb,
                                                        model="hog")
                encs = face_recognition.face_encodings(rgb, boxes)
                if len(encs)>1:
                    encodings.append(encs[0])
                    print(names_dir," has ", len(encs)," encodings.")
                elif len(encs) == 1:
                    encodings.append(encs[0])
                else:
                    print(names_dir," has no encodings.")
                
        if i > 0:
            np.savez_compressed(ENCODING_DIR+"/"+faceId+".npz", encodings)
        else:
            print("No images for", names_dir)
        del encodings[:]

    with open(NAMES_FILE, "w") as output:
        json.dump(faces, output)

    print("Calculate Known Embedding took:", round(perf_counter()-timeS, 3))


# run cal known face embeddings


calc_save_known_face_embeddings()
